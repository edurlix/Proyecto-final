using System;
using Xunit;

namespace SocialMedia.UnitTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
