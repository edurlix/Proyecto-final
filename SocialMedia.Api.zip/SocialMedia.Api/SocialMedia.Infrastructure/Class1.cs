﻿using System;

namespace SocialMedia.Infrastructure
{
    public class Class1
    {
    }
}
