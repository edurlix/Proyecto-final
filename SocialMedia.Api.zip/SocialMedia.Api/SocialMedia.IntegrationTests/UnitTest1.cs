using System;
using Xunit;

namespace SocialMedia.IntegrationTests
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
